package com.jpmc.ForexApi.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public abstract class BaseForex {

	protected Map<String,BigDecimal> getRatesFeed() {
		Map<String,BigDecimal> rates = new HashMap<>();
		rates.put("INRUSD", new BigDecimal("76.56"));
		rates.put("INREUR", new BigDecimal("102.43"));
		
		return rates;
	}
}
