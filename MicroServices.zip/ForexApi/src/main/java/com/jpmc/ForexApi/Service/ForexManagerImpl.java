package com.jpmc.ForexApi.Service;

import java.math.BigDecimal;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jpmc.ForexApi.dto.ForexRequest;
import com.jpmc.ForexApi.dto.ForexResponse;

@Service
public class ForexManagerImpl extends BaseForex implements ForexManager {

	@Override
	public ForexResponse getRates(ForexRequest req) {
		
		String key= req.getSrcCCY().concat(req.getDestCCY());
		
		Map<String,BigDecimal> rates = this.getRatesFeed();
		
		ForexResponse fxRes = new ForexResponse();

		if (rates.containsKey(key))
		{
			
			BigDecimal bdRates= rates.get(key);
			fxRes.setReqId(req.getReqId());
			fxRes.setRate(bdRates.floatValue());
				}else 
				{
					fxRes.setReqId(req.getReqId());
					fxRes.setRate(0);
				}
				
		return fxRes;
	}

}
