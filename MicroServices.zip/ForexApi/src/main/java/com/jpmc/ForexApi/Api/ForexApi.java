package com.jpmc.ForexApi.Api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.ForexApi.Service.ForexManager;
import com.jpmc.ForexApi.dto.ForexRequest;
import com.jpmc.ForexApi.dto.ForexResponse;

@RestController
@RequestMapping("api")
public class ForexApi {

	@Autowired
	private ForexManager fxService;
	
	@PostMapping(value = "/fx", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ForexResponse> getForexRates(@RequestBody  ForexRequest fxReq){
		
		
		ForexResponse res= fxService.getRates(fxReq);
		
		System.out.println(res);
		return new ResponseEntity<ForexResponse>(res,HttpStatus.OK);
		
		
	}
}
