package com.jpmc.ForexApi.Service;

import com.jpmc.ForexApi.dto.ForexRequest;
import com.jpmc.ForexApi.dto.ForexResponse;

public interface ForexManager {
	
	public ForexResponse getRates(ForexRequest req);

}
