package com.jpmc.ForexApi.dto;

import java.io.Serializable;

@SuppressWarnings("serial")
public abstract class BaseModel implements Serializable {

}
