package com.jpmc.ForexApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ForexApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
