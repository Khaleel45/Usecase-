package com.jpmc.Credit.Consumer;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.stereotype.Component;

import com.jpmc.Credit.payload.FundsTransferRequest;

@Component
public class CreditReq {

	
	@Value(value= "${fundstransfer.topic.name}")
	private String topicName;
	
	@KafkaListener
	(topicPartitions = @TopicPartition(topic ="${fundstransfer.topic.name}", partitions = {"0","1", "2", "3", "4"}),
			containerFactory = "fundsTransferReqKafkaListenerContainerFactory")

	public void FTMessageListener(FundsTransferRequest req) {
		System.out.println("From Consumer");
		System.out.println(req);
		
	}
}
