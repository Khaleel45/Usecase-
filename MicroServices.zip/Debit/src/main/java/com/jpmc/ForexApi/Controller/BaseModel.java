package com.jpmc.ForexApi.Controller;

import java.io.Serializable;

public abstract class BaseModel implements Serializable {

	
	
private String CustId;

public String getCustId() {
	return CustId;
}

public void setCustId(String custId) {
	CustId = custId;
}


}
