package com.jpmc.ForexApi.producer;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import com.jpmc.ForexApi.Controller.FundsTransferRequest;

@Service
public class FundsTransferProducer extends BaseProducer {
	
	@Autowired
	private KafkaTemplate<String, FundsTransferRequest> kafkaTemplate;
	
	@Value("${fundsTransfer.topic.name}")
	private String topicName;

	public void sendTReq(FundsTransferRequest req) {
		
		req.setCustId(UUID.randomUUID().toString() );
		kafkaTemplate.send(topicName, req);
	}

}
