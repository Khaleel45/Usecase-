package com.jpmc.ForexApi.producer;

public abstract class BaseProducer {

}
