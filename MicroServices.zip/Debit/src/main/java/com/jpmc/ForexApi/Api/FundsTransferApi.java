package com.jpmc.ForexApi.Api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.ForexApi.Controller.FundsTransferRequest;
import com.jpmc.ForexApi.producer.FundsTransferProducer;

@RestController
@RequestMapping("api")
public class FundsTransferApi extends BaseController {

	@Autowired
	private FundsTransferProducer ftProducer;
	
	
	@PostMapping(value= "/ft", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Boolean> PostMessage(@RequestBody FundsTransferRequest req){
		
		System.out.println("===");
		System.out.println(req);
		
		ftProducer.sendTReq(req);
	
		return new ResponseEntity<Boolean>(Boolean.TRUE, HttpStatus.OK);
	}

}
