package com.jpmc.ForexApi.Api;

public abstract class BaseController {

}
