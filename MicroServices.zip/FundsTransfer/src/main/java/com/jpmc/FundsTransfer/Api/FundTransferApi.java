package com.jpmc.FundsTransfer.Api;

import java.util.Date;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jpmc.ForexApi.dto.ForexRequest;
import com.jpmc.ForexApi.dto.ForexResponse;
import com.jpmc.FundsTransfer.Service.ForexServiceRemoteClient;
import com.jpmc.FundsTransfer.dto.DoPaymentRequest;
import com.jpmc.FundsTransfer.dto.DoPaymentResponse;

@RequestMapping("api")
@RestController
public class FundTransferApi {
	
	
	@Autowired
	private ForexServiceRemoteClient fxClient;
	
	
	@PostMapping(value = "/doPayement", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<DoPaymentResponse> doPayment(@RequestBody DoPaymentRequest req)
	{
		System.out.println("Request popup "+ new Date());
		
		ForexRequest fxReq = new ForexRequest();
		fxReq.setDestCCY(req.getCcy());
		fxReq.setSrcCCY("INR");
		fxReq.setReqId(UUID.randomUUID().toString());
		
		ForexResponse fxRes = fxClient.getForexRates(fxReq);
		
		System.out.println("From Payment" + fxRes.toString());
		
		
		DoPaymentResponse res = new DoPaymentResponse();
		res.setStatus(true);
		res.setTxnRefNumber(UUID.randomUUID().toString());
		return new ResponseEntity<DoPaymentResponse>(res,HttpStatus.OK);
		
		
		
	}
}
