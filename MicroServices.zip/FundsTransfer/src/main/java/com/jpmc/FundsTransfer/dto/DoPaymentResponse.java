package com.jpmc.FundsTransfer.dto;



public class DoPaymentResponse extends BaseModel {
	
	private Boolean status;
	private String reqIdentifier;
	private String txnRefNumber;
	public Boolean getStatus() {
		return status;
	}
	public void setStatus(Boolean status) {
		this.status = status;
	}
	public String getReqIdentifier() {
		return reqIdentifier;
	}
	public void setReqIdentifier(String reqIdentifier) {
		this.reqIdentifier = reqIdentifier;
	}
	public String getTxnRefNumber() {
		return txnRefNumber;
	}
	public void setTxnRefNumber(String txnRefNumber) {
		this.txnRefNumber = txnRefNumber;
	}
	
	
	}