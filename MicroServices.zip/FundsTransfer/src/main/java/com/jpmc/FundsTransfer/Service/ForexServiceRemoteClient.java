package com.jpmc.FundsTransfer.Service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jpmc.ForexApi.dto.ForexRequest;
import com.jpmc.ForexApi.dto.ForexResponse;
import com.jpmc.FundsTransfer.config.FeignConfig;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

@FeignClient(name = ForexServiceRemoteClient.SERVICE_NAME, configuration = FeignConfig.class)
public interface ForexServiceRemoteClient {

	String SERVICE_NAME = "forex-api";

	@RequestMapping(method= RequestMethod.POST, value = "/api/fx")
	@CircuitBreaker(name=SERVICE_NAME)
	public ForexResponse getForexRates(@RequestBody  ForexRequest fxReq);
}
