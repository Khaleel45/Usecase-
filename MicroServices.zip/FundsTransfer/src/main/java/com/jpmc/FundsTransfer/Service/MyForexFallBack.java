package com.jpmc.FundsTransfer.Service;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

import com.jpmc.ForexApi.dto.ForexRequest;
import com.jpmc.ForexApi.dto.ForexResponse;

@Component
public class MyForexFallBack implements ForexServiceRemoteClient
{
	
	@Override
	public ForexResponse getForexRates(@RequestBody  ForexRequest fxReq){
		 
		ForexResponse res = new ForexResponse();
		res.setRate(0);
		res.setReqId(fxReq.getReqId());
		
		
		return res;
	}

}
