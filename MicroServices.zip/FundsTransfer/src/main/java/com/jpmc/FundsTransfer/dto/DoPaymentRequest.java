package com.jpmc.FundsTransfer.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class DoPaymentRequest extends BaseModel {
	
	private String reqIdentifier;
	private String srcAcc;
	private String destAcc;
	private int amount;
	private String ccy;
	
	@JsonFormat( pattern = "dd-mm-yyyy")
	private Date ts;

	public String getReqIdentifier() {
		return reqIdentifier;
	}

	public void setReqIdentifier(String reqIdentifier) {
		this.reqIdentifier = reqIdentifier;
	}

	public String getSrcAcc() {
		return srcAcc;
	}

	public void setSrcAcc(String srcAcc) {
		this.srcAcc = srcAcc;
	}

	public String getDestAcc() {
		return destAcc;
	}

	public void setDestAcc(String destAcc) {
		this.destAcc = destAcc;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public Date getTs() {
		return ts;
	}

	public void setTs(Date ts) {
		this.ts = ts;
	}



	
	
}
