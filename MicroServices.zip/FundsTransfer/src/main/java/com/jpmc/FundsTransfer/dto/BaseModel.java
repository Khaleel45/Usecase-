package com.jpmc.FundsTransfer.dto;

import java.io.Serializable;

public abstract class BaseModel implements Serializable {

}
