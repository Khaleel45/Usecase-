package com.jpmc.FundsTransfer.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.jpmc.FundsTransfer.Service.MyForexFallBack;

import feign.Feign;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.feign.FeignDecorators;
import io.github.resilience4j.feign.Resilience4jFeign;
import io.github.resilience4j.ratelimiter.RateLimiter;

@Configuration
public class FeignConfig {
	
	@Autowired
	private CircuitBreakerRegistry registry;

	@Autowired
	private MyForexFallBack fallback;
	
	
	@Bean
	@Scope("prototype")
	
	public Feign.Builder feignBuilder(){
		
		CircuitBreaker circuitBreaker = CircuitBreaker.ofDefaults("forex-api");
		RateLimiter ratelimiter = RateLimiter.ofDefaults("forex-api");
		FeignDecorators  decorators = FeignDecorators.builder() 
				                      .withRateLimiter(ratelimiter)
				                      .withCircuitBreaker(circuitBreaker)
				                      .withFallback(fallback)
				                      .build();
		return Resilience4jFeign.builder(decorators);
	}
	
}
